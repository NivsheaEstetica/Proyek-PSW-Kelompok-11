<!doctype html>
<html lang="en">
  <head>
  	<title>Daftar - Labotarium</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 col-lg-4">
					<div class="login-wrap py-5">
		      	<h3 class="text-center mb-0">Pendaftaran Akun</h3>

				<form action="cek_tambahLogin.php" method="POST" class="login-form">
		      		<div class="form-group">
		      			<div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-user-circle-o"></span></div>
		      			<input type="text" class="form-control" placeholder="Username" name="Username" required>
		      		</div>

                    <div class="form-group">
                        <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-lock"></span></div>
                    <input type="password" class="form-control" placeholder="Password" name="Password" required>
                    </div>

                    <div class="form-group">
                        <div class="icon d-flex align-items-center justify-content-center"><span><i class="fa fa-user"></i></span></div>
                    <input type="text" class="form-control" placeholder="Nama Lengkap" name="Nama" required>
                    </div>

                    <div class="form-group">
                        <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-envelope"></span></div>
                    <input type="email" class="form-control" placeholder="Email" name="Email" required>
                    </div>

                    <div class="form-group">
                        <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-mobile"></span></div>
                    <input type="text" class="form-control" placeholder="No Hp" name="NoHp" required>
                    </div>
	         
	            <div class="form-group">
	            	<button type="submit" class="btn form-control btn-primary rounded submit px-2">Daftar</button>
	            </div>
	          </form>
	       

	        </div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

