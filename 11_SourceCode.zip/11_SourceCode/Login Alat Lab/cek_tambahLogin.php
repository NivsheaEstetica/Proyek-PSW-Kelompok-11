<?php
    include 'koneksi.php';

    $Username = $_POST['Username'];
    $Password = $_POST['Password'];
    $Nama = $_POST['Nama'];
    $Email = $_POST['Email'];
    $NoHp = $_POST['NoHp'];

    mysqli_query($koneksi,"insert into login values('','$Username','$Password','$Nama','$Email','$NoHp')");

    header("location:index.php");
?>