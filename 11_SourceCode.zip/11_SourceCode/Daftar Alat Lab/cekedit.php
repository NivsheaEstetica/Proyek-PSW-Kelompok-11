
<?php
    include 'koneksi.php';

    $KodeAlat = $_POST['KodeAlat'];
    $NamaAlat = $_POST['NamaAlat'];
    $Keterangan = $_POST['Keterangan'];
    $FungsiAlat = $_POST['FungsiAlat'];
    $KetersediaanAlat = $_POST['KetersediaanAlat'];
    $BagianAlat = $_POST['BagianAlat'];

    mysqli_query($koneksi,"update daftaralatlab set KodeAlat='$KodeAlat',NamaAlat='$NamaAlat',Keterangan='$Keterangan',FungsiAlat='$FungsiAlat',KetersediaanAlat='$KetersediaanAlat',BagianAlat='$BagianAlat'");

    header("location:editDataAlat.php");
?>