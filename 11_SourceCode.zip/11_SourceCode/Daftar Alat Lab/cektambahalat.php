<?php
    include 'koneksi.php';

    $KodeAlat = $_POST['KodeAlat'];
    $NamaAlat = $_POST['NamaAlat'];
    $Keterangan = $_POST['Keterangan'];
    $FungsiAlat = $_POST['FungsiAlat'];
    $KetersediaanAlat = $_POST['KetersediaanAlat'];
    $BagianAlat = $_POST['BagianAlat'];

    mysqli_query($koneksi,"insert into daftaralatlab values('$KodeAlat','$NamaAlat','$Keterangan','$FungsiAlat','$KetersediaanAlat','$BagianAlat')");

    header("location:editDataAlat.php");
?>