<?php
    include 'koneksi.php';

    $KodeAlat = $_GET['KodeAlat'];

    mysqli_query($koneksi,"delete from daftaralatlab where KodeAlat='$KodeAlat'");

    header("location:editDataAlat.php");



?>