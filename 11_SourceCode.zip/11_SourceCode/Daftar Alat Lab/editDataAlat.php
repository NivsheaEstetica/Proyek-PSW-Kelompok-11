<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	  <title>DashBoard AlatLab</title>
	  <link rel="stylesheet" type="text/css" href="style.css">
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>

	  <link rel="stylesheet" href="style.css">

	</head>
	<body>
	<?php 
        session_start();
        if($_SESSION['status']!="login"){
            header("location:../Login Alat Lab/login.php?pesan=belum_login");
        }
    ?>
	<Nav>
 <nav class="navbar navbar-expand-lg navbar-light" 
 style="background-color:	#2F4F4F;
 padding:14px;
 ">
  <div class="container-fluid">

    <a class="navbar-brand" href="#" 
    style="color: #F0FFFF; 
    font-weight: bold;
    ">
    Labotarium IT DELL</a>


    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-lg-1 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">

          <a class="nav-link " aria-current="page" href="../Home Page/index.php" 
          style="color: #F0FFFF;"
          >
          <i class="fa fa-home" aria-hidden="true"></i> Home</a>

        </li>
    
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"  style="color: #F0FFFF;"><i class="fa fa-thermometer-empty" aria-hidden="true"></i>  Alat Lab</a>
          <ul class="dropdown-menu">
               <li><a class="dropdown-item" href="../Daftar Alat Lab/daftarAlatLab.php"><i class="fa fa-list-ol" aria-hidden="true"></i> Daftar Alat Lab</a></li>
			   <li><a class="dropdown-item" href="../Daftar Alat Lab/editDataAlat.php"><i class="fa fa-tachometer" aria-hidden="true"></i> Dasboard Alat Lab</a></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"  style="color: #F0FFFF;"><i class="fa fa-list-alt" aria-hidden="true"></i> Menu Peminjaman</a>
          <ul class="dropdown-menu">
               <li><a class="dropdown-item" href="../Peminjaman Alat Lab/pinjam.php"><i class="fa fa-cart-plus" aria-hidden="true"></i> Peminjaman</a></li>
               <li><a class="dropdown-item" href="../Peminjaman Alat Lab/laporan.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Laporan Peminjaman</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="../Home Page/about.php" tabindex="-1" aria-disabled="true"  style="color: #F0FFFF;"><i class="fa fa-book" aria-hidden="true"></i> About</a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"  style="color: #F0FFFF;"><i class="fa fa-lock" aria-hidden="true"></i> <?php echo $_SESSION['username']; ?></a>
          <ul class="dropdown-menu">
               <li><a class="dropdown-item" href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout </a></li>
          </ul>
        </li>
      
      </ul>
    </div>
  </div>
</nav>

<header>

		<div class="container box">
			<h1 align="center">Menu Pengaturan Alat Lab</h1>
			<br />
			<div class="table-responsive">
				<br />

				<div align="right">
					<a href="tambahalat.php"><button type="button" class="btn btn-warning" id="tambah">Tambah Alat Lab</button></a>
				</div>

				<br/><br/>
				<table id="alatlab" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th >Kode Alat</th>
							<th >Nama Alat</th>
							<th >Keterangan</th>
							<th >Fungsi Alat</th>
							<th >Ketersediaan Alat</th>
							<th >Bagian Alat</th>
							<th>Edit</th>
							<th>Delete</th>
						</tr>
					</thead>

               <?php
                  include 'koneksi.php';
                  $data = mysqli_query($koneksi,"Select * From daftaralatlab");
                  while($i = mysqli_fetch_array($data))
                  {
                     ?>
                     <tr>
                        <td><?php echo $i['KodeAlat']; ?></td>
                        <td><?php echo $i['NamaAlat']; ?></td>
                        <td><?php echo $i['Keterangan']; ?></td>
                        <td><?php echo $i['FungsiAlat']; ?></td>
                        <td><?php echo $i['KetersediaanAlat']; ?></td>
                        <td><?php echo $i['BagianAlat']; ?></td>
                        <td>
                         <a href="edidata.php?KodeAlat=<?php echo $i['KodeAlat']; ?>"><input type="submit" id="edit" class="btn btn-success" value="Edit"></a>
                        </td>
                        <td>
									        <a href="cek_hapus.php?KodeAlat=<?php echo $i['KodeAlat'];?>"><input type="submit" class="btn btn-danger" value="Delete" /></a>
                        </td>
                     </tr>
                     <?php
                  }
                   ?>
				</table>
				
			</div>
		</div>
	</header>
	</body>
</html>
