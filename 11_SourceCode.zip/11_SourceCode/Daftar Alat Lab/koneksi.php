<?php
    $koneksi = mysqli_connect("localhost","root","","labotarium");

    if(mysqli_connect_errno())
    {
        echo "Database Error ". mysqli_connect_error();
    }
 
?>