-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2021 at 04:31 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `labotarium`
--

-- --------------------------------------------------------

--
-- Table structure for table `daftaralatlab`
--

CREATE TABLE `daftaralatlab` (
  `KodeAlat` varchar(10) NOT NULL,
  `NamaAlat` varchar(50) NOT NULL,
  `Keterangan` varchar(500) NOT NULL,
  `FungsiAlat` varchar(500) NOT NULL,
  `KetersediaanAlat` int(11) NOT NULL,
  `BagianAlat` varchar(200) NOT NULL,
  `GambarAlat` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `daftaralatlab`
--

INSERT INTO `daftaralatlab` (`KodeAlat`, `NamaAlat`, `Keterangan`, `FungsiAlat`, `KetersediaanAlat`, `BagianAlat`, `GambarAlat`) VALUES
('11223344', 'Mikroskop', 'kondisi baik', 'Mengamati objek yang ukurannya kecil', 23, 'Lensa okuler, Tabung mikroskop, Revoler, Lensa Objektif, Diafragma, Cermin, Makrometer/Mikrometer', 0x20),
('11223345', 'kawat kasa', 'Kondisi baik', 'Menahan beaker atau labu ketika proses pemanasan menggunakan pemanas bunsen atau pemanas spritus', 20, ' ', 0x20),
('11223346', 'CentriFuge', 'Kondisi Baik', 'Memisahkan Partikel organel yang larut sehingga membentuk endapan yang terpisah berdasarkan perbedaan massa jenis dari partikel pembentuklarutan tersebut', 20, ' ', 0x20),
('11223347', 'Mortar Stamper', 'Kondisi Baik', 'Menggerus atau menumbuk obat-obatan agar menjadi halus', 21, 'Mortir dan Stamper', 0x20),
('11223348', 'Rak Tabung Reaksi', 'Kondisi Baik', 'Tempat untuk meletakan tabung reaksi yang berjumlah banyak', 20, ' ', 0x20),
('11223349', 'PH Meter', 'Kondisi Baik', 'Mengukur PH (kadar keasaman atau basa) suatu cairan', 25, 'Elektrode kaca, Elektrode Referensi, Termometer, Amplifier, Mikroprosesor', 0x20),
('11223350', 'Labu Erlenmeyer', 'Kondisi Baik', 'Sebagai alat untuk mengukur,menyimpan,dan mencampur cairan', 21, ' ', 0x20),
('11223351', 'Tabung Reaksi', 'Kondisi Baik', 'Tempat mereaksikan dua larutan/bahan kimia atau lebih, serta sebagai tempat mengembangbiakan mikroba dalam media cair', 21, ' ', 0x20),
('11223352', 'Pipet Tetes', 'Kondisi Baik', 'Memindahkan larutan dari suatu wadah ke wadah lain dengan jumlah yang sangat sedikit dan dengan tingkat ketelitian pengukuran volume yang sangat rendah', 20, ' ', 0x20),
('11223353', 'Spatula Kaca', 'Kondisi Baik', 'Sebagai sendok kecil yang juga digunakan untuk mengambil bahan kimia.', 20, ' ', 0x20),
('11223354', 'Beakre Gelas', 'Kondisi Baik', 'Sebagai tempat mereaksikan bahan, tempat menampung bahan kimia berupa larutan, padatan, pasta ataupun tepung, tempat melarutkan bahan dan tempat memanaskan bahan', 21, ' ', 0x20),
('11223355', 'Timbangan Analitik', 'Kondisi Baik', 'Mengukur massa kecil dalam rentang sub-miligram.', 20, 'Piringan timbangan, Anak timbangan, Waterpass, Tombol pengaturan, Tombol mode, Tombol on/off', 0x20),
('11223356', 'Kaki Tiga', 'Kondisi Baik', 'Sebagai penahan kawat kasa dan penyangga ketika proses pemanasan', 25, ' ', 0x20),
('11223357', 'Rotator dan Mixer', 'Kondisi Baik', 'Menggerakan sebuah plat (attachment) dengan gerakan yang memutar. Gerakan satu ini diharapkan bisa mengocok sampel pada wadah yang diletakkan di atasnya', 20, 'Overhead Stirer, Hot Plate stirer, Tube Rotator, Vortex Mixer', 0x20),
('11223358', 'Penjepit Tabung Reaksi', 'Kondisi Baik', 'Digunakan untuk menjepit tabung reaksi disaat proses pemanasan. Atau bisa juga digunakan untuk mengambil kertas saring dan benda-benda lab lain disaat kondisi alat tersebut panas', 30, ' ', 0x20),
('11223359', 'Bunsen', 'Kondisi Baik', 'Digunakan untuk pemanasan, sterilisasi, dan pembakaran', 28, 'Tabung Logam, Keran panjang, Dua lubang pada bagian dasar mengendalikan kadar udara yang bercampur dengan gas sehingga menghasilkann api tanpa asap', 0x20),
('11223360', 'Corong kaca', 'Kondisi Baik', 'Alat bantu untuk memindah / memasukkan larutan ke wadah / tempat yang mempunyaai dimensi pemasukkan sampel bahan kecil', 22, ' ', 0x20),
('11223361', 'Sarung Tangan', 'Kondisi Baik', 'menahan efek dari zat kimia yang bisa merusak kulit', 30, ' ', 0x20),
('11223362', 'Mikropipet', 'Kondisi Baik', 'Memindahkan cairan dalam jumlah kecil secara akurat', 25, 'Plunger button, Shaft volume adjusment knob, Plastic tip, Ejector arm, Tip ejector button', 0x20),
('11223363', 'Mikroskop Elektron', 'Kondisi Baik', 'Melakukan pembesaran objek sampai 2 juta kali, yang menggunakan elektro statik dan elektro magnetik untuk mengontrol pencahayaan dan tampilan gambar serta memiliki kemampuan pembesaran objek serta resolusi yang jauh lebih bagus', 20, 'Lensa okuler, Tabung Mikroskop, Revolver, Lensa Objektif, Diafragma, Cermin,Makrometer/Mikrometer', 0x20);

-- --------------------------------------------------------

--
-- Table structure for table `daftar inventaris`
--

CREATE TABLE `daftar inventaris` (
  `Id_alat` char(10) NOT NULL,
  `Nama_alat` varchar(30) NOT NULL,
  `Jenis_alat` varchar(20) NOT NULL,
  `Model` varchar(20) NOT NULL,
  `Ruangan` varchar(15) NOT NULL,
  `Detail` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `Np` varchar(25) NOT NULL,
  `nama_dosen` varchar(50) NOT NULL,
  `alamat_dosen` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `koordinatorlab`
--

CREATE TABLE `koordinatorlab` (
  `Id_koordinator` varchar(8) NOT NULL,
  `nama_koordinator` varchar(50) NOT NULL,
  `alamat_koordinator` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Nama` varchar(200) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `NoHp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `Username`, `Password`, `Nama`, `Email`, `NoHp`) VALUES
(1, 'rosa', '1234', 'Rosa', 'rosa@gmail.com', '0897675342'),
(2, 'ucok', '1234', 'rosa sinaga', 'rosa@gmail.com', '089636646298');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `Nim_mahasiswa` varchar(8) NOT NULL,
  `nama_mahasiswa` varchar(50) NOT NULL,
  `alamat_mahasiswa` varchar(50) NOT NULL,
  `Jurusan` varchar(20) NOT NULL,
  `Semester` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `Id_Peminjaman` char(10) NOT NULL,
  `Id_inventaris` varchar(50) NOT NULL,
  `Nim_Mahasiswa` varchar(20) NOT NULL,
  `Tanggal_Peminjaman` int(50) NOT NULL,
  `Tanggal_Pengembalian` date NOT NULL,
  `Waktu_Pinjam` time NOT NULL,
  `Jumlah_Pinjaman` int(11) NOT NULL,
  `Keterangan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftaralatlab`
--
ALTER TABLE `daftaralatlab`
  ADD PRIMARY KEY (`KodeAlat`);

--
-- Indexes for table `daftar inventaris`
--
ALTER TABLE `daftar inventaris`
  ADD PRIMARY KEY (`Id_alat`);

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`Np`);

--
-- Indexes for table `koordinatorlab`
--
ALTER TABLE `koordinatorlab`
  ADD PRIMARY KEY (`Id_koordinator`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`Nim_mahasiswa`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`Id_Peminjaman`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
